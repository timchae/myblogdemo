create unique index PRIMARY_KEY_6C
    on POST (ID);

